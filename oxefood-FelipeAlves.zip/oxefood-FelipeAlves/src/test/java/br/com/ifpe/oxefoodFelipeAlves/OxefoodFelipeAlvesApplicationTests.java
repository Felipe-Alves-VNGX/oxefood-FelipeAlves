package br.com.ifpe.oxefoodFelipeAlves;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class OxefoodFelipeAlvesApplicationTests {

	@Test
	void contextLoads() {
	}

}
