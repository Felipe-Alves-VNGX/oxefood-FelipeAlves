package br.com.ifpe.oxefoodFelipeAlves;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OxefoodFelipeAlvesApplication {

	public static void main(String[] args) {
		SpringApplication.run(OxefoodFelipeAlvesApplication.class, args);
	}

}
